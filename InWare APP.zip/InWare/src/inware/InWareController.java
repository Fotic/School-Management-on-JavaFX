/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inware;

import static inware.Users.getPrem;
import static inware.Users.getfN;
import static inware.Users.getsN;
import static inware.Users.getGen;
import static inware.Users.getBd;
import static inware.Users.getCl;
import static inware.Users.getgFN;
import static inware.Users.getgSN;
import static inware.Users.getfNum;
import static inware.Users.getAbs;
import static inware.Users.getDabs;
import static inware.Users.getNabs;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class InWareController implements Initializable {

    @FXML Button search_btn, print;
    @FXML Button search_btn1;
    @FXML Button manage,manage1,manage2;
    @FXML Label fN, sN, gen, bd, cl, abs, Dabs, Nabs, gFN, gSN, fNum;
    @FXML TextArea result, result1;
    @FXML TextField search_field, search_field1;
    StringBuilder rsl = new StringBuilder();
    StringBuilder rsl1 = new StringBuilder();

    @Override
    public void initialize(URL url, ResourceBundle rb) {                        //Ginetai run me to pou anoiksi h scene

        if (getPrem().equals("Admin")) {    //Elenxi ean o user einai admin
            manage.setDisable(false);       // ean Nai energopoih ta buttons
            manage1.setDisable(false);
            manage2.setDisable(false);
            print.setDisable(false);
        }

        fN.setText(getfN());sN.setText(getsN()); gen.setText(getGen());         //Mpenoun times sta label pou ta trava apo to UserAuth
        bd.setText(getBd());cl.setText(getCl());abs.setText(getAbs());          //meso static parameter
        gFN.setText(getgFN());gSN.setText(getgSN());fNum.setText(getfNum());
        Dabs.setText(getDabs());Nabs.setText(getNabs());
    }

    public static boolean containsOneOrMore(String text, String[] search) {     //Ektelei elenxo sta search variable pou exontai
        for (String s : search) {                                               //apo tis if
            if (!text.contains(s)) {
                return false;
            }
        }
        return true;
    }
    
    @FXML
    public void PressedSearch(ActionEvent event) throws IOException {           //Ektelei Search sto arxeio ton mathiton
        if (searchStudent() == false) {
            result.setStyle("-fx-font:15 monospace;-fx-text-fill: red");
            result.setText("Αδυναμία Εύρεσης Μαθητή");
        } else {
            result.setStyle("-fx-font:15 monospace;-fx-text-fill: black");
            rsl.setLength(0);
        }
    }
    
    public boolean searchStudent() throws IOException {                         //Sto search o admin mporei na dei perissotera pragmata
        Path p = Paths.get("src", "inware", "users.txt");
        Scanner in = new Scanner(p);
        boolean i = false;
        String search =search_field.getText();
        String[] search1 = search.split("[,]");
                
        if (getPrem().equals("Admin")) {
        String format = "%-10s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s\n";
        rsl.append(String.format(format,"Όνομα:","Επίθετο:","Φύλο:","Ημ. Γέννησης:","Τάξη:","Όνομα Κηδεμόνα:","Επώνυμο Κηδεμόνα:","Τηλ. Κηδεμόνα:","Συν. Απουσίες:","Ημ. Τελ. Απουσίας:","Αρ. Τελ. Απουσίας:","Μάθημα 1:","Μάθημα 2:","Μάθημα 3:","Μάθημα 4:","Μάθημα 5:","Μάθημα 6:","Μ.Ο.:"));
            while (in.hasNextLine()) {
                String line = in.nextLine();
                String[] fields = line.split("[,]");
                if (containsOneOrMore(line, search1)) {
                    if (fields[1].equals("_"))continue;                         //Fix Student Bug sto txt file
                    if (fields[4].equals("null") && fields[5].equals("null"))continue;  //Ama einai Admin h Kidemonas den ton dixni
                    rsl.append(String.format(format,fields[4],fields[5],fields[6],fields[7],fields[8],fields[9],fields[10],fields[11],fields[12],fields[13],fields[14],fields[15],fields[16],fields[17],fields[18],fields[19],fields[20],fields[21]));
                    i = true;
                    
                }
            }
        }else {
        String format = "%-10s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s\n";
        rsl.append(String.format(format,"Όνομα:","Επίθετο:","Φύλο:","Ημ. Γέννησης:","Τάξη:","Μάθημα 1:","Μάθημα 2:","Μάθημα 3:","Μάθημα 4:","Μάθημα 5:","Μάθημα 6:","Μ.Ο.:"));
            while (in.hasNextLine()) {
                String line = in.nextLine();
                String[] fields = line.split("[,]");
                if (containsOneOrMore(line, search1)) {
                    if (fields[1].equals("_"))continue;                         //Fix Student Bug sto txt file
                    if (fields[4].equals("null") && fields[5].equals("null"))continue;  //Ama einai Admin h Kidemonas den ton dixni
                    rsl.append(String.format(format,fields[4],fields[5],fields[6],fields[7],fields[8],fields[15],fields[16],fields[17],fields[18],fields[19],fields[20],fields[21]));
                    i = true;
                }
            }
        }
        result.setText(rsl.toString());
        in.close();
        return i;
    }

    @FXML
    public void PrintStudent(ActionEvent event) throws IOException {            //Ektelei Print tous Mathites tou Sxoleiou
        ObservableList<CharSequence> paragraph = result.getParagraphs();        //Gia na emfanistoun sosta prepei na anoixti me Notepad++
        Iterator<CharSequence> iter = paragraph.iterator();
        BufferedWriter bf = new BufferedWriter(new FileWriter(new File("src/inware/PrintStudent.txt")));
        while (iter.hasNext()) {
            CharSequence seq = iter.next();
            bf.append(seq);
            bf.newLine();
        }
        bf.flush();
        bf.close();
    }
     
    @FXML
    public void PressedSearch1(ActionEvent event) throws IOException {          //Ektelei Search sto arxeio ton kathigiton
        if (searchTeacher() == false) {
            result1.setStyle("-fx-font:15 monospace;-fx-text-fill: red");
            result1.setText("Αδυναμία Εύρεσης Καθηγητή");
        } else {
            result1.setStyle("-fx-font:15 monospace;-fx-text-fill: black");
            rsl1.setLength(0);
        }
    }

    public boolean searchTeacher() throws IOException {                         //Sto search o admin mporei na dei perissotera pragmata
        Path p = Paths.get("src", "inware", "teachers.txt");
        Scanner in = new Scanner(p);
        boolean i = false;
        String search =search_field1.getText();
        String[] search1 = search.split("[,]");
        
        if (getPrem().equals("Admin")) {
            String format = "%-10s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s\n";
            rsl1.append(String.format(format,"Όνομα:","Επίθετο:","Φύλο:","Ημ. Γέννησης:","Ειδικότητα:","Τηλέφωνο:","Διεύθυνση:","Διδ. Μάθημα 1:","Διδ. Μάθημα 2:","Διδ. Μάθημα 3:","Διδ. Μάθημα 4:","Διδ. Μάθημα 5:","Διδ. Μάθημα 6:"));
            while (in.hasNextLine()) {
                String line = in.nextLine();
                String[] fields = line.split("[,]");
                if (containsOneOrMore(line, search1)) {
                    if (fields[1].equals("_"))continue;                         //Fix Teacher Bug sto txt file
                    rsl1.append(String.format(format,fields[1],fields[2],fields[3],fields[4],fields[5],fields[6],fields[7],fields[8],fields[9],fields[10],fields[11],fields[12],fields[13]));
                    i = true;
                }
            }
        } else {
            String format = "%-10s %20s %20s %20s %20s %20s %20s %20s %20s %20s %20s\n";
            rsl1.append(String.format(format,"Όνομα:","Επίθετο:","Φύλο:","Ημ. Γέννησης:","Ειδικότητα:","Διδ. Μάθημα 1:","Διδ. Μάθημα 2:","Διδ. Μάθημα 3:","Διδ. Μάθημα 4:","Διδ. Μάθημα 5:","Διδ. Μάθημα 6:"));
            while (in.hasNextLine()) {
                String line = in.nextLine();
                String[] fields = line.split("[,]");
                if (containsOneOrMore(line, search1)) {
                    if (fields[1].equals("_"))continue;                         //Fix Teacher Bug sto txt file
                    rsl1.append(String.format(format,fields[1],fields[2],fields[3],fields[4],fields[5],fields[8],fields[9],fields[10],fields[11],fields[12],fields[13]));
                    i = true;
                }
            }
        }
        result1.setText(rsl1.toString());
        in.close();
        return i;
    }

    @FXML
    public void PressedManageStudent() throws IOException {                     //Anoigi to Manage Student scene
        Stage pstage = new Stage();
        AnchorPane root = FXMLLoader.load(getClass().getResource("ManageStudent.fxml"));
        pstage.getIcons().add(new Image("/icon/sm.png"));
        pstage.setTitle("Διαχείριση Μαθητών");
        Scene scene = new Scene(root);
        pstage.setScene(scene);
        pstage.setResizable(false);
        pstage.show();
    }
    
    @FXML
    public void PressedManageTeacher() throws IOException {                     //Anoigi to Manage Teacher scene
        Stage pstage = new Stage();
        AnchorPane root = FXMLLoader.load(getClass().getResource("ManageTeacher.fxml"));
        pstage.getIcons().add(new Image("/icon/sm.png"));
        pstage.setTitle("Διαχείριση Καθηγητών");
        Scene scene = new Scene(root);
        pstage.setScene(scene);
        pstage.setResizable(false);
        pstage.show();
    }
    
    @FXML
    public void PressedManageUser() throws IOException {                        //Anoigi to Manage User scene
        Stage pstage = new Stage();
        AnchorPane root = FXMLLoader.load(getClass().getResource("ManageUser.fxml"));
        pstage.getIcons().add(new Image("/icon/sm.png"));
        pstage.setTitle("Διαχείριση Χρηστών");
        Scene scene = new Scene(root);
        pstage.setScene(scene);
        pstage.setResizable(false);
        pstage.show();
    }
}
