/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inware;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


/**
 * FXML Controller class
 *
 * @author Fotic
 */
public class ManageStudentController implements Initializable {

    @FXML TextField ID, fN, sN, gen, bd, cl, gFN, gSN, gNum;          //Eisagogi Mathiti
    @FXML TextField ID4, fN1, sN1, gen1, bd1, cl1, gFN1, gSN1, gNum1; //Epeksergasia Dedomenon Mathiti
    @FXML TextField ID1, glossa, math, fis, xim, prog, gym;           //Eisagogi Mathimaton
    @FXML TextField ID3, abs, Dabs, Fabs;                             //Eisagogi Apousion
    @FXML TextField ID2;                                              //Diagrafi Mathiti
    @FXML Button Add, Add1, Add2, SearchSt, Edit, SearchAbs, Delete, Clean, Clean1, Clean2, Clean3, Clean4;
    @FXML Label lbl1,lbl2,lbl3,lbl4,lbl5;
            
    @Override
    public void initialize(URL url, ResourceBundle rb) {        //Katharismos kenon grammmon me to pou anigi sto scene
        Path p = Paths.get("src", "inware", "users.txt");
        try {
            Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
            try (BufferedReader in = Files.newBufferedReader(p);
                 PrintWriter out = new PrintWriter(Files.newBufferedWriter(tempFile))) {
                for (String line; (line = in.readLine()) != null;) {
                    line = line.trim();
                    if (!line.isEmpty()) {
                        out.println(line);
                    }
                }
            }
            Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
            Files.delete(tempFile);
            
        } catch (IOException ex) {
            Logger.getLogger(ManageStudentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void UseAddStudent(ActionEvent event) throws IOException {       //Eisagogi Mathiton
        FileWriter fW = new FileWriter("src/inware/users.txt", true);
        BufferedWriter bW = new BufferedWriter(fW);
        bW.newLine();

        bW.write(ID.getText() + ",");
        bW.write("null,null,null,"+fN.getText() + ",");
        bW.write(sN.getText() + ",");
        bW.write(gen.getText() + ",");
        bW.write(bd.getText() + ",");
        bW.write(cl.getText() + "' Λυκείου,");
        bW.write(gFN.getText() + ",");
        bW.write(gSN.getText() + ",");
        bW.write(gNum.getText()+",null,null,null,null,null,null,null,null,null,null");
        bW.close();
        lbl1.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
        lbl1.setText("Επιτυχείς Καταχώριση Μαθητή");

    }

    @FXML
    public void UseReset() {    //Katharismos ton text field
        ID.setText("");
        fN.setText("");
        sN.setText("");
        gen.setText("");
        bd.setText("");
        cl.setText("");
        gFN.setText("");
        gSN.setText("");
        gNum.setText("");
        lbl1.setText("");
    }

    @FXML
    public void UseSearchStudent(ActionEvent event) throws IOException {       //Epeksergasia Mathiton
        String searchText = ID4.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
        
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    fN1.setText(fields[4]) ;
                    sN1.setText(fields[5]);
                    gen1.setText(fields[6]);
                    bd1.setText(fields[7]);
                    cl1.setText(fields[8]);
                    gFN1.setText(fields[9]);
                    gSN1.setText(fields[10]);
                    gNum1.setText(fields[11]);
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);

    }
      
    @FXML
    public void UseEditStudent(ActionEvent event) throws IOException {       //Epeksergasia Mathiton
        String searchText = ID4.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
        
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    fields[4] = fN1.getText();
                    fields[5] = sN1.getText();
                    fields[6] = gen1.getText();
                    fields[7] = bd1.getText();
                    fields[8] = cl1.getText() + "' Λυκείου";
                    fields[9] = gFN1.getText();
                    fields[10] = gSN1.getText();
                    fields[11] = gNum1.getText();
                    lbl2.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl2.setText("Επιτυχείς Ενημέρωση Μαθητή");
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);

    }

    @FXML
    public void UseReset4() {    //Katharismos ton text field
        ID4.setText("");
        fN1.setText("");
        sN1.setText("");
        gen1.setText("");
        bd1.setText("");
        cl1.setText("");
        gFN1.setText("");
        gSN1.setText("");
        gNum1.setText("");
        lbl2.setText("");
    }
        
    @FXML
    public void UseAddLesson() throws IOException {         //Perasma mathimaton sinfona me to ID
        String searchText = ID1.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
        double MO = (Double.parseDouble(glossa.getText()) + Double.parseDouble(math.getText())
                    + Double.parseDouble(fis.getText()) + Double.parseDouble(xim.getText())
                    + Double.parseDouble(prog.getText()) + Double.parseDouble(gym.getText())) / 6;
               
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    fields[15]  = "Γλώσσα-" + glossa.getText();
                    fields[16] = "Μαθηματικά-" + math.getText();
                    fields[17] = "Φυσική-" + fis.getText();
                    fields[18] = "Χημεία-" + xim.getText();
                    fields[19] = "Προγραμματισμός-" + prog.getText();
                    fields[20] = "Γυμναστική-" +gym.getText();
                    fields[21] = String.format(Locale.US, "%.2f",MO);
                    lbl3.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl3.setText("Επιτυχείς Εισαγωγή Βαθμών");
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);
    }

    @FXML
    public void UseReset1() {    //Katharismos ton text field
        ID1.setText("");
        glossa.setText("");
        math.setText("");
        fis.setText("");
        xim.setText("");
        prog.setText("");
        gym.setText("");
        lbl3.setText("");
    }

    @FXML
    public void UseSearchStAbs() throws IOException {                //Kanei Anazitisi Apousion sinfona me to ID
        String searchText = ID3.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                     Fabs.setText(fields[12]);
                     Dabs.setText(fields[13]);
                     abs.setText(fields[14]);
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);
    }
    
    @FXML
    public void UseAddAbs() throws IOException {                //Kanei Add tis Apousies sinfona me to ID
        String searchText = ID3.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    fields[12] = Fabs.getText();
                    fields[13] = Dabs.getText();
                    fields[14] = abs.getText();
                    lbl4.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl4.setText("Επιτυχείς Εισαγωγή Απουσιών");
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);
    }
    
    @FXML
    public void UseReset3() {    //Katharismos ton text field
        ID3.setText("");
        abs.setText("");
        Dabs.setText("");
        Fabs.setText("");
        lbl4.setText("");
    }

    @FXML
    public void UseDelete() throws IOException {                //Delete Mathiton sinfona me to ID
        String searchText = ID2.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])){ 
                    lbl5.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl5.setText("Επιτυχείς Διαγραφή Μαθητή");
                    continue;
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);
    }

    @FXML
    public void UseReset2() {    //Katharismos ton text field
        ID2.setText("");
        lbl5.setText("");
    }

}
