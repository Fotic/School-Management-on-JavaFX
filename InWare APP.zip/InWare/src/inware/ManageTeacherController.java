/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inware;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Fotic
 */
public class ManageTeacherController implements Initializable {

    @FXML TextField ID1, fName, sName, gen, bd, spec,fNum,adr;             //Eisagogi Kathigiti
    @FXML TextField ID4, fName1, sName1, gen1, bd1, spec1,fNum1,adr1;      //Epeksergasia Kathigiti
    @FXML TextField ID2;                                                   //Eisagogi Didaskomenon Mathimaton
    @FXML RadioButton y1,n1,y2,n2,y3,n3,y4,n4,y5,n5,y6,n6;                 //Eisagogi Didaskomenon Mathimaton
    @FXML TextField ID3;                                                   //Diagrafi Kathigiti
    @FXML Label lbl1,lbl2,lbl3,lbl4;
    @FXML  Button Add1, Add2, searchT, Edit, Delete, Clean1, Clean2, Clean3,Clean4;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {        //Katharismos kenon grammmon me to pou anigi sto scene
        Path p = Paths.get("src", "inware", "teachers.txt");
        try {
            Path tempFile = Files.createTempFile(p.getParent(), "teachersTemp", ".txt");
            try (BufferedReader in = Files.newBufferedReader(p);
                 PrintWriter out = new PrintWriter(Files.newBufferedWriter(tempFile))) {
                for (String line; (line = in.readLine()) != null;) {
                    line = line.trim();
                    if (!line.isEmpty()) {
                        out.println(line);
                    }
                }
            }
            Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
            Files.delete(tempFile);
            
        } catch (IOException ex) {
            Logger.getLogger(ManageStudentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
    @FXML
    public void UseAddTeacher(ActionEvent event) throws IOException {       //Eisagogi Kathigiton
        FileWriter fW = new FileWriter("src/inware/teachers.txt", true);
        BufferedWriter bW = new BufferedWriter(fW);
        bW.newLine();

        bW.write(ID1.getText() + ",");
        bW.write(fName.getText() + ",");
        bW.write(sName.getText() + ",");
        bW.write(gen.getText() + ",");
        bW.write(bd.getText() + ",");
        bW.write(spec.getText() + ",");
        bW.write(fNum.getText() + ",");
        bW.write(adr.getText()+ ",null,null,null,null,null,null");
        bW.close();
        lbl1.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
        lbl1.setText("Επιτυχείς Εισαγωγή Καθηγητή");

    }
    
    @FXML
    public void UseReset1() {    //Katharismos ton text field
        ID1.setText("");
        fName.setText("");
        sName.setText("");
        gen.setText("");
        bd.setText("");
        spec.setText("");
        fNum.setText("");
        adr.setText("");
        lbl1.setText("");
    }
    
    @FXML
    public void UseSearchTeacher(ActionEvent event) throws IOException {       //Epeksergasia Kathigiton
        String searchText = ID4.getText();
        Path p = Paths.get("src", "inware", "teachers.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "teachersTemp", ".txt");
        
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    fName1.setText(fields[1]) ;
                    sName1.setText(fields[2]);
                    gen1.setText(fields[3]);
                    bd1.setText(fields[4]);
                    spec1.setText(fields[5]);
                    fNum1.setText(fields[6]);
                    adr1.setText(fields[7]);   
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);

    }
    
    @FXML
    public void UseEditTeacher(ActionEvent event) throws IOException {       //Epeksergasia Kathigiton
        String searchText = ID4.getText();
        Path p = Paths.get("src", "inware", "teachers.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "teachersTemp", ".txt");
        
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    fields[1]= fName1.getText() ;
                    fields[2]= sName1.getText();
                    fields[3]= gen1.getText();
                    fields[4]= bd1.getText();
                    fields[5]= spec1.getText();
                    fields[6]= fNum1.getText();
                    fields[7]= adr1.getText();
                    lbl2.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl2.setText("Επιτυχείς Ενημέρωση Καθηγητή");
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);

    }

    @FXML
    public void UseReset4() {    //Katharismos ton text field
        ID4.setText("");
        fName1.setText("");
        sName1.setText("");
        gen1.setText("");
        bd1.setText("");
        spec1.setText("");
        fNum1.setText("");
        adr1.setText("");
        lbl2.setText("");
    }
    
    
    @FXML
    public void UseAddTeachLesson() throws IOException {         //Perasma didaskomenon mathimaton sinfona me to ID
        String searchText = ID2.getText();
        Path p = Paths.get("src", "inware", "teachers.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "teachersTemp", ".txt");
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    if (y1.isSelected())fields[8] = "Γλώσσα-" + y1.getText();
                    else                fields[8] = "Γλώσσα-" + n1.getText();
                    
                    if (y2.isSelected())fields[9] = "Μαθηματικά-" + y2.getText();
                    else                fields[9] = "Μαθηματικά-" + n2.getText();
                    
                    if (y3.isSelected())fields[10] = "Φυσική-" + y3.getText();
                    else                fields[10] = "Φυσική-" + n3.getText();
                    
                    if (y4.isSelected())fields[11] = "Χημεία-" + y4.getText();
                    else                fields[11] = "Χημεία-" + n4.getText();
                    
                    if (y5.isSelected())fields[12] = "Προγραμματισμός-" + y5.getText();
                    else                fields[12] = "Προγραμματισμός-" + n5.getText();
                    
                    if (y6.isSelected())fields[13] = "Γυμναστική-" + y6.getText();
                    else                fields[13] = "Γυμναστική-" + n6.getText();
                    lbl3.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl3.setText("Επιτυχείς Εισαγωγή Διδασκόμενων Μαθημάτων");
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);
    }
    
    @FXML
    public void UseReset2() {    //Katharismos ton text field
        ID2.setText("");
        y1.setSelected(false);
        n1.setSelected(false);
        y2.setSelected(false);
        n2.setSelected(false);
        y3.setSelected(false);
        n3.setSelected(false);
        y4.setSelected(false);
        n4.setSelected(false);
        y5.setSelected(false);
        n5.setSelected(false);
        y6.setSelected(false);
        n6.setSelected(false);
        lbl3.setText("");
    }
    
     @FXML
    public void UseDelete() throws IOException {                //Delete Kathigiton sinfona me to ID
		String searchText = ID3.getText();
        Path p = Paths.get("src", "inware", "teachers.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "teachersTemp", ".txt");
        
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])){
                    lbl4.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl4.setText("Επιτυχείς Διαγραφή Καθηγητή");
                    continue;
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);
    }
    
    @FXML
    public void UseReset3() {    //Katharismos ton text field
        ID3.setText("");
        lbl4.setText("");
    }
    
}
