/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inware;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Fotic
 */
public class ManageUserController implements Initializable {

    @FXML TextField ID,userN,pass;          //Eisagogi Xristi
    @FXML TextField ID1,userN1,pass1,ID2;   //Epeksergasia-Diagrafi Xristi
    @FXML RadioButton us,ad;                //Eisagogi Xristi
    @FXML RadioButton us1,ad1;              //Epeksergasia Xristi
    @FXML Label lbl1,lbl2,lbl3;
    @FXML Button add,clear,searchU,edit,clear1,delete,clear2;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {            //Katharismos kenon grammmon me to pou anigi sto scene
        Path p = Paths.get("src", "inware", "users.txt");
        try {
            Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
            try (BufferedReader in = Files.newBufferedReader(p);
                 PrintWriter out = new PrintWriter(Files.newBufferedWriter(tempFile))) {
                for (String line; (line = in.readLine()) != null;) {
                    line = line.trim();
                    if (!line.isEmpty()) {
                        out.println(line);
                    }
                }
            }
            Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
            Files.delete(tempFile);
            
        } catch (IOException ex) {
            Logger.getLogger(ManageStudentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
    @FXML
    public void UseAddUser(ActionEvent event) throws IOException {       //Eisagogi Xriston
        FileWriter fW = new FileWriter("src/inware/users.txt", true);
        BufferedWriter bW = new BufferedWriter(fW);
        bW.newLine();

        bW.write(ID.getText() + ",");
        bW.write(userN.getText() + ",");
        bW.write(pass.getText() + ",");
        if (us.isSelected())  
             bW.write(us.getText() + ",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null");
        else bW.write(ad.getText() + ",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null");
        bW.close();
        lbl1.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
        lbl1.setText("Επιτυχείς Εισαγωγή Χρήστη");
    }
    
    @FXML
    public void UseReset1() {    //Katharismos ton text field
        ID.setText("");
        userN.setText("");
        pass.setText("");
        us.setSelected(false);
        ad.setSelected(false);
        lbl1.setText("");
    }
    
    @FXML
    public void UseSearchUser(ActionEvent event) throws IOException {       //Epeksergasia Xriston
        String searchText = ID1.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
        
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    userN1.setText(fields[1]) ;
                    pass1.setText(fields[2]);
                    if(fields[3].equals("User")) us1.setSelected(true);
                    else                         ad1.setSelected(true);
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);

    }
      
    @FXML
    public void UseEditUser(ActionEvent event) throws IOException {       //Epeksergasia Xriston
        String searchText = ID1.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");

        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])) {
                    fields[1] = userN1.getText();
                    fields[2] = pass1.getText();
                    if (us1.isSelected())fields[3] = us1.getText();
                    else                 fields[3] = ad1.getText();
                    lbl2.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl2.setText("Επιτυχείς Επεξεργασία Χρήστη");
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);

    }
    
    @FXML
    public void UseReset2() {    //Katharismos ton text field
        ID1.setText("");
        userN1.setText("");
        pass1.setText("");
        us1.setSelected(false);
        ad1.setSelected(false);
        lbl2.setText("");
    }
    
     @FXML
    public void UseDeleteUser() throws IOException {                //Delete Xriston sinfona me to ID
        String searchText = ID2.getText();
        Path p = Paths.get("src", "inware", "users.txt");
        Path tempFile = Files.createTempFile(p.getParent(), "usersTemp", ".txt");
        
        try (BufferedReader reader = Files.newBufferedReader(p);
                BufferedWriter writer = Files.newBufferedWriter(tempFile)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("[,]");
                if (searchText.equals(fields[0])){
                    lbl3.setStyle("-fx-font:15 sherif;-fx-text-fill: green");
                    lbl3.setText("Επιτυχείς Διαγραφή Χρήστη");
                    continue;
                }
                writer.write(String.join(",", fields));
                writer.newLine();
            }
        }
        // copy new file & delete temporary file
        Files.copy(tempFile, p, StandardCopyOption.REPLACE_EXISTING);
        Files.delete(tempFile);
    }
        
    @FXML
    public void UseReset3() {    //Katharismos ton text field
        ID1.setText("");
        userN1.setText("");
        pass1.setText("");
        us1.setSelected(false);
        ad1.setSelected(false);
        lbl2.setText("");
    }
    
}
