/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inware;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fotic
 */
public class UserAuthController implements Initializable {

    @FXML
    Button ok, reset;
    @FXML
    TextField username;
    @FXML
    PasswordField password;
    @FXML
    Label status;
    Users prem, fN, sN, gen, bd, cl, abs, Dabs, Nabs, gFN, gSN, fNum;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    public void PressedOK(Event event) throws InterruptedException, IOException {   //Ektelei ton elenxo   
        String u = username.getText();
        String p = password.getText();

        if (verifyLogin(u, p) == true) {
            try {
                openNewScene();
                ok.getScene().getWindow().hide();
            } catch (IOException ex) {
                Logger.getLogger(UserAuthController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            status.setStyle("-fx-font:15 sherif;-fx-text-fill: red");
            status.setText("Αποτυχία Σύνδεσης");

        }
    }

    @FXML
    public void PressedReset() {    //Katharismos tou text field
        username.setText("");
        password.setText("");
        status.setText("");
    }

    private void openNewScene() throws IOException {        //Kalei tin epomeni scene
        Stage pstage = new Stage();
        AnchorPane root = FXMLLoader.load(getClass().getResource("InWare.fxml"));
        pstage.getIcons().add(new Image("/icon/sm.png"));
        pstage.setTitle("InWare");
        Scene scene = new Scene(root);
        pstage.setScene(scene);
        pstage.setResizable(false);
        pstage.show();
    }

    public boolean verifyLogin(String UserName, String Password) throws IOException { // Elenxi ean to username kai pass einai sosta
        Path p = Paths.get("src", "inware", "users.txt");
        BufferedReader reader = Files.newBufferedReader(p);
        String line;

        while ((line = reader.readLine()) != null) {
            String[] fields = line.split("[,]");
            if (UserName.equals(fields[1]) && Password.equals(fields[2])) {
                prem.setPrem(fields[3]);                     //Pernao times sto epomeno scene!!!!

                fN.setfN(fields[4]);
                sN.setsN(fields[5]);
                gen.setGen(fields[6]);
                bd.setBd(fields[7]);
                cl.setCl(fields[8]);
                gFN.setgFN(fields[9]);
                gSN.setgSN(fields[10]);
                fNum.setfNum(fields[11]);
                abs.setAbs(fields[12]);
                Dabs.setDabs(fields[13]);
                Nabs.setNabs(fields[14]);
                reader.close();
                return true;
            }
        }
        return false;
    }

}
