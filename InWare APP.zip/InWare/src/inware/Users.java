package inware;

public class Users {
    public static String Prem,fN,sN,gen,bd,cl,abs,Dabs,Nabs,gFN,gSN,fNum;

    public static String getDabs() {
        return Dabs;
    }

    public static void setDabs(String Dabs) {
        Users.Dabs = Dabs;
    }

    public static String getNabs() {
        return Nabs;
    }

    public static void setNabs(String Nabs) {
        Users.Nabs = Nabs;
    }

    public static String getPrem() {
        return Prem;
    }

    public static void setPrem(String Prem) {
        Users.Prem = Prem;
    }

    public static String getfN() {
        return fN;
    }

    public static void setfN(String fN) {
        Users.fN = fN;
    }

    public static String getsN() {
        return sN;
    }

    public static void setsN(String sN) {
        Users.sN = sN;
    }

    public static String getGen() {
        return gen;
    }

    public static void setGen(String gen) {
        Users.gen = gen;
    }

    public static String getBd() {
        return bd;
    }

    public static void setBd(String bd) {
        Users.bd = bd;
    }

    public static String getCl() {
        return cl;
    }

    public static void setCl(String cl) {
        Users.cl = cl;
    }

    public static String getAbs() {
        return abs;
    }

    public static void setAbs(String abs) {
        Users.abs = abs;
    }

    public static String getgFN() {
        return gFN;
    }

    public static void setgFN(String gFN) {
        Users.gFN = gFN;
    }

    public static String getgSN() {
        return gSN;
    }

    public static void setgSN(String gSN) {
        Users.gSN = gSN;
    }

    public static String getfNum() {
        return fNum;
    }

    public static void setfNum(String fNum) {
        Users.fNum = fNum;
    }

}
